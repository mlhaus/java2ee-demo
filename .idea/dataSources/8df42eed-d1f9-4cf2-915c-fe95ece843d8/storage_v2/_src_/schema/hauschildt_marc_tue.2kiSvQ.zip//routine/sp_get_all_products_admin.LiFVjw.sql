create
    definer = Java21Tomcat10@`%` procedure sp_get_all_products_admin()
BEGIN
    SELECT prod_id, prod_name, prod_price, prod_desc, products.vend_id, vend_name
    FROM products JOIN vendors
    ON products.vend_id = vendors.vend_id;
END;

